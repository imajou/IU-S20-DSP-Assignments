# DSP Assignment 3

Innopolis University, 2020  
Digital Signal Processing  
Assignment 3


## Team

Arina Fedorovskaya (a.fedorovskaya@innopolis.ru)  
Gleb Petrakov (g.petrakov@innopolis.ru)  


## Structure

* `task1/` - all stuff related to task 1, including source samples and results  
* `task2/` - all stuff related to task 2, including source samples  
* `presentation.pdf` - our presentation  
* `Linear Systems and Signal Convolution.pdf` - task description

